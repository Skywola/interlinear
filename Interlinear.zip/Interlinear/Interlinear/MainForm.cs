﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace Interlinear
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		string fileName = string.Empty;
		string f1Name = string.Empty;
		string f2Name = string.Empty;
		int fNum1 = 0;
		int fNum2 = 0;
		string buildHeader = string.Empty;
		List<string> f1List = new List<string>();
		List<string> f2List = new List<string>();
		FileIO FIO = new FileIO();
		string encoding = string.Empty;
		
		public void setUTF8(string f1Path){
			encoding = FileIO.GetEncoding(f1Path);
			if(encoding != "UTF8"){
				string f1 = FIO.readFile(f1Path);  // Open file
				FIO.writeFile(f1Path, f1); // Write the file back in UTF8 format
			}		
		}
		
		public void Create() {
		// File name and path have been resolved, begin processing
		lblSection.ForeColor = Color.Black;
		// First check to make sure the file numbers match
		fNum1 = getNumberFromFile(Properties.f1Path);  // Returns -1 if no number
		fNum2 = getNumberFromFile(Properties.f2Path);  // Returns -1 if no number
		fileName = setFileName(fNum1, fNum2);
		setUTF8(Properties.f1Path);
		setUTF8(Properties.f2Path);
		string f1 = FIO.readFile(Properties.f1Path);  // Open file
		string f2 = FIO.readFile(Properties.f2Path);  // Open file
		f1List = f1.Split(new string[] { "\r\n" }, StringSplitOptions.None).ToList();
		f2List = f2.Split(new string[] { "\r\n" }, StringSplitOptions.None).ToList();
		btnSaveEdit.PerformClick();
		}
			
		void BtnSaveEditClick(object sender, EventArgs e)
		{
			while(getNext() & !Properties.exit){
				if(Properties.count == 1){
					setSectionNumber(Properties.item1, Properties.item2);
					Properties.buildTxt1 = string.Empty;
					Properties.buildTxt2 = string.Empty;
					continue;
				}
				// Timeline
				if(Properties.count == 2){ // Add timeline
					buildHeader = buildHeader + filterTimeLine(Properties.item1);
					Properties.time = Properties.item1;
					continue;
				}
				// Subtitle
				if(Properties.count > 2){
					if(!endOfSection()){
						// text lines, go
						Properties.buildTxt1 = Properties.buildTxt1 + Properties.item1;
						Properties.buildTxt2 = Properties.buildTxt2 + Properties.item2;                      
					}
				}
			}
			
			string path1 = Path.GetDirectoryName(Properties.f1Path);
			string path2 = Path.GetDirectoryName(Properties.f2Path);
			string filePath = path1 + "\\" +  fileName;
			FIO.writeFile(filePath, Properties.output);
			// Set New FileNames
			Properties.f1Path = path1 + setNextFileName(Properties.f1Path) + ".srt";
			Properties.f2Path = path2 + setNextFileName(Properties.f2Path) + ".srt";
			if(File.Exists(Properties.f1Path) & File.Exists(Properties.f1Path)){
				Create();
			}
		}

		string setNextFileName(string filePath){
			string fileBaseName = string.Empty;
		    string path = Path.GetDirectoryName(filePath);
		    string fName = Path.GetFileNameWithoutExtension(filePath);
		    string num = GeneralFns.doRight(fName, 2);
		    //string num = GeneralFns.doRight(fName, 6);
		    int fNum = Int32.Parse(num);
		    fNum = fNum + 1;
		    if(fNum < 10){
		    	fileBaseName = GeneralFns.doLeft(fName, fName.Length - 1);
		    } else {
		    	fileBaseName = GeneralFns.doLeft(fName, fName.Length - 2);
		    }
		    fName = fileBaseName + fNum.ToString();
		    return path + fName;
		}		
		
		bool getNext(){
			if(f1List.Count > 0 & f2List.Count > 0){
				Properties.item1 = f1List.ElementAt(0);
				Properties.item2 = f2List.ElementAt(0);
				f1List.RemoveAt(0);
				f2List.RemoveAt(0);
				Properties.count = Properties.count + 1;
				return true;
			} else {
				return false;
			}
		}
		
		void processSubtitles(string item1, string item2){
			if(item1 == "\r\n" | item1 == "\r\n"){
				// Mismatch - one text line and one blank line
				Properties.subtitle1 = item1;
				Properties.subtitle2 = item2;
				showSection(item1, item2);  // display so they can be edited
				Properties.exit = true;
			} else {
			// text lines, go
			Properties.buildTxt1 = Properties.buildTxt1 + item1;
			Properties.buildTxt2 = Properties.buildTxt2 + item2;                      
			}
		}
		
		// Adds created section to the bottom, checks for empty lists
		bool endOfSection(){
			bool appended = false;
			// Append when empty line
			if(checkForBlankLines()){
				string crlf = Environment.NewLine;
				string section = Properties.section1 + crlf + Properties.time + crlf + 
					             Properties.buildTxt1 + crlf + Properties.buildTxt2 + crlf;
				Properties.output = Properties.output + section + crlf;
				buildHeader = string.Empty;
				Properties.count = 0;
				appended = true;
			}
			// Are lists empty?
			if(f1List.Count < 1 | f2List.Count < 1){
					Properties.exit = true;
			}
			return appended;
		}
		
		bool checkForBlankLines(){
			bool endOfASection = false;
			if(Properties.item1 == "\r\n" & Properties.item1 == "\r\n"){
				endOfASection = true;
			}
			if(Properties.item1 == "" & Properties.item1 == ""){
				endOfASection = true;
			}
			return endOfASection;
		}
		
		
		void setSectionNumber(string item1, string item2)
		{
			// Get section number or "mismatch" if fail
			buildHeader = getNumber(item1, item2);
			if(buildHeader == "mismatch"){ // mismatch
				txtSection1.Text = item1;
				txtSection2.Text = item2;
				if(f1List.Count > 0){
					txtTime1.Text = f1List.ElementAt(0);
				}
				if(f2List.Count > 0){
					txtTime2.Text = f2List.ElementAt(0);
				}
				// number mismatch causes exit, so user can edit file
				lblSection.ForeColor = Color.Red;
				Properties.exit = true;
			}
			Properties.section1 = item1;
			Properties.section2 = item2;		
		}
		
		
		
		
		void showSection(string item1, string item2){
			txtSection1.Text = Properties.section1;
			txtSection2.Text = Properties.section2;
			txtTime1.Text = Properties.time;
			txtSub1.Text = item1;
			txtSub2.Text = item2;
		}
		

		
		static int getNumberFromFile(string filePath){
			string fileName =  Path.GetFileNameWithoutExtension(filePath);
			string num = GeneralFns.doRight(fileName, 2);
		    int intout = Int32.Parse(num);
		    return intout;
		}
		
		
		// Returns section number or -1 if fail    
		static string getNumber(string fNum1, string fNum2){
		    string l1 = filterLineNumber(fNum1);
		    string l2 = filterLineNumber(fNum2);
		    if(l1 == l2){
		        return l1; // Numbers match as they should
		    } else {
		        // Line number mismatch
		        return "mismatch";
		    }
		}
		
		
		static string setFileName(int fNum1, int fNum2){
			string fileName = "";
			
		    if(fNum1 == -1 | fNum2 == -1){
		       fileName = "Interlinear.srt";  // One file  only
		       Properties.go = false;
		       return fileName;
			} else{
		        if(fNum1 == fNum2){
		            if(fNum1 < 10){
		                fileName = "Interlinear-Vol0" + fNum1 + ".srt";
		                return fileName;
		            }
		            fileName = "Interlinear-Vol" + fNum1 + ".srt";
		            return fileName;
				}else{
		            // Mismatch in file numbers.
		            // message_mismatched_file_numbers(file1_name, file2_name);
		            // Display the mismatch
		            return "0";
		        }
		    }
		            
		}
		
		static string filterLineNumber(string num){
			string numout = string.Empty;
		    num = num.Replace("eleven", "11");
		    num = num.Replace("thirty", "30");
		    num = num.Replace("0.", "0");
		    num = num.Replace("1.", "1");
		    num = num.Replace("2.", "2");
		    num = num.Replace("3.", "3");
		    num = num.Replace("4.", "4");
		    num = num.Replace("5.", "5");
		    num = num.Replace("6.", "6");
		    num = num.Replace("7.", "7");
		    num = num.Replace("8.", "8");
		    num = num.Replace("9.", "8");
		    num = num.Replace("6th", "6");
		    numout = num.Replace("7th", "7");
		    return numout;
		}
		
		static string filterTimeLine(string time){
			string timeout = string.Empty;
		    time = time.Replace(" -- ", " -->");
		    time = time.Replace("- ->", "-->");
		    time = time.Replace("  -", " -");
		    time = time.Replace(" >", "->");
		    time = time.Replace(": ", ":");
		    time = time.Replace(" :", ":");
		    timeout = time.Replace(",", ".");
		    return timeout;
		    
		}
		
		
		void BtnTopClick(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog01 = new OpenFileDialog();
			Cursor.Current = Cursors.WaitCursor;
	
			openFileDialog01.Title = "Open File";
			openFileDialog01.DefaultExt = "srt";
			openFileDialog01.Filter = "Subtitle|*.srt|" + "Text Files|*.txt";
			// "Rich Text Files|*.rtf|" + "Text Files|*.txt|HTML Files|" + "*.htm|All Files|*.*";
			openFileDialog01.FilterIndex = 1;
	
			try {
				if (openFileDialog01.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
					Properties.f1Path = openFileDialog01.FileName;
					if ((Properties.f1Path != null)) {
						Properties.topFile = FIO.readFile(Properties.f1Path);
						txtFilePath1.Text = Properties.f1Path;
					}
				}
				Cursor.Current = Cursors.Default;
	
			} catch (Exception ex) {
	
				string m = "Error:" + ex.StackTrace + ". . . ." + Environment.NewLine + " Exception:  " + ex.ToString();
				MessageBox.Show(m, "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		void BtnBottomClick(object sender, EventArgs e)
		{
				OpenFileDialog openFileDialog01 = new OpenFileDialog();
			Cursor.Current = Cursors.WaitCursor;
	
			openFileDialog01.Title = "Open File";
			openFileDialog01.DefaultExt = "srt";
			openFileDialog01.Filter = "Subtitle|*.srt|" + "Text Files|*.txt";
			openFileDialog01.FilterIndex = 1;
	
			try {
				if (openFileDialog01.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
					Properties.f2Path = openFileDialog01.FileName;
					if ((Properties.f2Path != null)) {
						Properties.bottomFile = FIO.readFile(Properties.f2Path);
						txtFilePath2.Text = Properties.f2Path;
					}
				}
				Cursor.Current = Cursors.Default;
	
			} catch (Exception ex) {
	
				string m = "Error:" + ex.StackTrace + ". . . ." + Environment.NewLine + " Exception:  " + ex.ToString();
				MessageBox.Show(m, "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		void BtnCreateClick(object sender, EventArgs e)
		{
			Create();
		}
		void BtnCloseClick(object sender, EventArgs e)
		{
			Application.Exit();
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		

}
}