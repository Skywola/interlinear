﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.IO;



public class FileIO
	{
		Form FrmFileIOErr = new System.Windows.Forms.Form();

		
		public string readFile(string path, bool createIfNotPresent = true) {
			try {
				if (File.Exists(path) == true) {
					FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
					StreamReader sr = new StreamReader(fs);
					fs.Seek(0, SeekOrigin.Begin);
					// Set cursor postion within stream
					path = sr.ReadToEnd();
					sr.Close();
					fs.Close();
				} else {
					if (createIfNotPresent == false) {
		
						string message = "The file you are attempting to open located at : " + path + " no longer exists at that location.";
						MessageBox.Show(message, "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
						path = "";
					}
				}
			} catch (Exception ex) {

				string m = "Error:" + ex.StackTrace + ". . . ." + Environment.NewLine + " Exception:  " + ex.ToString();
				MessageBox.Show(m, "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			return path;  // "path" is used so I do not have to dim a new variable, it actually returns the file content!
		}

		// Open file using a dialog box 
		//  Because FIO resets current path to the new file, it must run first, then in your richtextbox code, you 
		//  must check for how to apply the text, based on whether the file being opened is a RTF file or not.
		// See the note below this procedure for an example
		public string OpenFile()
		{
			OpenFileDialog openFileDialog01 = new OpenFileDialog();
			string strExt = null;
			string newPath = null;
			string fileContents = "";
			RichTextBox rtfBox = new RichTextBox();

			Cursor.Current = Cursors.WaitCursor;

			openFileDialog01.Title = "RTE - Open File";
			openFileDialog01.DefaultExt = "rtf";
			openFileDialog01.Filter = "Rich Text Files|*.rtf|" + "Text Files|*.txt|HTML Files|" + "*.htm|All Files|*.*";
			openFileDialog01.FilterIndex = 1;

			try {
				if (openFileDialog01.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
					newPath = openFileDialog01.FileName;
					if ((newPath != null)) {
						string filePath = newPath;
						FileInfo FIO = new FileInfo(newPath);
						strExt = Path.GetExtension(newPath);
						strExt = strExt.ToUpper();
						switch (strExt) {
							case ".RTF":
								rtfBox.LoadFile(openFileDialog01.FileName, RichTextBoxStreamType.RichText);
								fileContents = rtfBox.Rtf;
								break;
							default:
								rtfBox.Text = readFile(openFileDialog01.FileName);
								fileContents = rtfBox.Text;
								break;
						}
					}
				}
				Cursor.Current = Cursors.Default;

			} catch (Exception ex) {

				string m = "Error:" + ex.StackTrace + ". . . ." + Environment.NewLine + " Exception:  " + ex.ToString();
				MessageBox.Show(m, "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			return fileContents;
		}


		#region "WriteFile"

		// OVERLOADED Text files (non-RichTextBox), UNICODE
		public void writeFile(string path, string txtStrng, bool acknowledge = false)
		{
			try {
				string routePath = Path.GetDirectoryName(path);
				if (!Directory.Exists(routePath)) {
					Directory.CreateDirectory(routePath);
				}
				//OLD Changed 8-21-2018 StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.Unicode);
				StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.UTF8);
				//??StreamWriter sw = new StreamWriter(path, false, System.Text.UTF8Encoding.UTF8);  // WTF is the difference?
				sw.Write(txtStrng);
				sw.Close();
				if (acknowledge == true) {
					MessageBox.Show("File saved.");
				}
			} catch (Exception ex) {
				MessageBox.Show("Error: " + ex.ToString(), "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// this requires that a RichTextBox be passed in
		public void saveFileAs(ref RichTextBox fileData, bool acknowledge = false)
		{
			SaveFileDialog SaveFileDialog1 = new SaveFileDialog();
			string fileExtension = "";
			RichTextBox RTB = new RichTextBox();

			try {
				RTB.Rtf = fileData.Rtf;
				SaveFileDialog1.Title = "RTE - Save File";
				SaveFileDialog1.DefaultExt = "rtf";
				SaveFileDialog1.Filter = "Rich Text Files|*.rtf|" + "Text Files|*.txt|" + "HTML Files|*.htm" + "|All Files|*.*";
				SaveFileDialog1.FilterIndex = 1;
				SaveFileDialog1.ShowDialog();
				if (string.IsNullOrEmpty(SaveFileDialog1.FileName)) {
					return;
				}
				fileExtension = System.IO.Path.GetExtension(SaveFileDialog1.FileName);
				fileExtension = fileExtension.ToUpper();
				switch (fileExtension) {
					case ".RTF":
						RTB.SaveFile(SaveFileDialog1.FileName, RichTextBoxStreamType.RichText);
						break;
					default:
						writeFile(SaveFileDialog1.FileName, RTB.Text);
						break;
				}

				if (acknowledge == true) {
					string caption = "Saved";
					MessageBox.Show("File saved.", caption, MessageBoxButtons.OK);
				}

			} catch (Exception ex) {

				string m = "Error:" + ex.StackTrace + ". . . ." + Environment.NewLine + " Exception:  " + ex.ToString();
				MessageBox.Show(m, "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		public void createDirectoryIfItDoesNotExist(string FilePath)
		{
			try {
				// if there is no directory, create one in the Environment.SpecialFolder.CommonApplicationData folder
				string folder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
				if (!Directory.Exists(folder)) {
					Directory.CreateDirectory(FilePath);
				}
			} catch (Exception ex) {
				MessageBox.Show("Error: " + ex.ToString(), "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		public void createFileIfItDoesNotExist(string filepath)
		{
			try {
				// if there is no file, create one
				if (!File.Exists(filepath)) {
					FileStream fs = new FileStream(filepath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
					fs.Close();
				}

			} catch (Exception ex) {
				MessageBox.Show("Error: " + ex.ToString(), "Error Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		#endregion

		public string getFileExtension(string path)
		{
			path = System.IO.Path.GetExtension(path);
			return path.ToUpper();
			// uses path to output Extension
		}


		public string getFileNameWithoutExtension(string filePath)
		{
			return Path.GetFileNameWithoutExtension(filePath);
		}


		
		/// <summary>
		/// Determines a text file's encoding by analyzing its byte order mark (BOM).
		/// Defaults to ASCII when detection of the text file's endianness fails.
		/// </summary>
		/// <param name="filePath">The text file to analyze.</param>
		/// <returns>The detected encoding.</returns>
		public static string GetEncoding(string filePath)
		{
		    // Read the BOM
		    var bom = new byte[4];
		    using (var file = new FileStream(filePath, FileMode.Open, FileAccess.Read))
		    {
		        file.Read(bom, 0, 4);
		    }
		
		    // Analyze the BOM
		    if (bom[0] == 0x2b && bom[1] == 0x2f && bom[2] == 0x76) return "UTF7";  // Encoding.UTF7;
		    if (bom[0] == 0xef && bom[1] == 0xbb && bom[2] == 0xbf) return "UTF8";
		    if (bom[0] == 0xff && bom[1] == 0xfe) return "Unicode"; //UTF-16LE
		    if (bom[0] == 0xfe && bom[1] == 0xff) return "BigEndianUnicode"; //UTF-16BE
		    if (bom[0] == 0 && bom[1] == 0 && bom[2] == 0xfe && bom[3] == 0xff) return "UTF32"; 
		    return "ASCII";
		}		
		




}
