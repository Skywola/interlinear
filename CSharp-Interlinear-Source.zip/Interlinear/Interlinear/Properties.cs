﻿using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

public static class Properties
	{
	public static string AppName = "Interlinear";
	// ReportError
	public static RichTextBox pReportError;
	public static string topFile = string.Empty;
	public static string bottomFile = string.Empty;
	public static bool go = true;
	public static string f1Path = string.Empty;
	public static string f2Path = string.Empty;
	public static string output = string.Empty;
	
	// This is a complete Section
	public static string lastSectionNumber = string.Empty;
	public static string sectionNumberTop = string.Empty;
	public static string sectionNumberBottom = string.Empty;
	public static string time1 = string.Empty;
	public static string time2 = string.Empty;
	public static string subtitleTop = string.Empty;
	public static string subtitleBottom = string.Empty;
	
	public static bool exitSave = false;
	public static int count = 0;
	public static bool series = true;
	public static bool leave = false;
	public static bool writeFile = true;

	public static string buildTxt1 = string.Empty;
	public static string buildTxt2 = string.Empty;	
	

	
		
}

