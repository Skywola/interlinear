﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Xml.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;

// Note that this uses the InStr method, which requires the use
// if the indexof method in C#
//TestPos = InStr(1, SearchString, SearchChar, CompareMethod.Binary)

public class GeneralFns{

	public static string doTrim(string param){
		param = param.Replace(" ", "");
		return param;
	}
	
	
	// If test = "1234567" & length = 4 then "1234"
	public static string doLeft(string param, int length){
		if(param == null){return "";}
		if(param.Length < length | length < 0){return "";}
		string result = param.Substring(0, length);
		return result;
	}
	
	// If test = "1234567" & length = 4 then "4567"
	public static string doRight(string param, int length){
		if(param == null){return "";}
		if(param.Length < length | length < 0){return "";}
		string result = param.Substring(param.Length - length, length);
		return result;
	}
	

	// If test = "1234567" & startIndex = 5 length = 2 then "67"
	public static string doMid(string param, int startIndex, int length){
		if(param == null){return "";}
		if(param.Length < length){return "";}
		if(startIndex < 0 | startIndex > param.Length){return "";}
		if(param.Length < startIndex + length){return "";}
		string result = param.Substring(startIndex, length);
		return result;
	}
	
	// If test = "strafe" & index = 3 newChar = '%' then "st%afe"
	public static  string doMid(string input, int index, char newChar)  {
		if (input == null) { return "" ;}
		if(input.Length < index){return "";}
		if(index < 0){return "";}
		char[] chars = input.ToCharArray();
		chars[index-1] = newChar;
		string test = new string(chars);
		return new string(chars);
	}
	
	// If test = "strafe" & ch = '%' then 0
	// If test = "strafe" & ch = 'f' then 4
	public static int doInStr(string sText, char ch){
		if (sText == null) { return -1;}
		int iVal = (int)sText.IndexOf(ch); // 0 is start index and can be modified.
		return iVal;
	}

	// If test = "strafe" & pos = 4, ch = '%' then 0
	// If test = "strafe" & pos = 4,  ch = 'f' then 4
	public static int doInStr(string sText, int pos, char ch){
		if (sText == null) { return -1;}
		if(sText.Length < pos){return -1;}
		int iVal = (int)sText.IndexOf(ch, pos); // 0 is start index and can be modified.
		return iVal;
	}
	
	// 0 is start index and can be modified.
	// If test = "strafe" & sValue = "af" then 3
	public static int doInStr(string sText, string findString){
		if (sText == null) { return -1;}
		if (findString == null) { return -1;}
		int iVal = (int)sText.IndexOf(findString, StringComparison.CurrentCulture);
		return iVal;
	}
	
	// Looks for the findString from the position given
	// If test = "strafe" & pos = 4,  ch = 'af' then -1
	// If test = "strafe" & pos = 3,  ch = 'af' then 3
	public static int doInStr(int start, string sText, string findString){
		if (sText == null) { return -1;}
		if (findString == null) { return -1;}
		if(sText.Length < start){return -1;}
		if(sText.Length < findString.Length){return -1;}
		int iVal = (int)sText.IndexOf(findString, start, StringComparison.CurrentCulture); // 0 is start index and can be modified.
		return iVal;
	}
	
	// Looks for the findString from the position given
	// If test = "strafe" & pos = 4,  ch = 'af' then -1
	// If test = "strafe" & pos = 3,  ch = 'af' then 3
	public static int doInStr(string sText, string findString, int startIndex, int count){
		if (sText == null) { return -1;}
		if (findString == null) { return -1;}
		if(sText.Length < startIndex){return -1;}
		if(sText.Length < startIndex + count){return -1;}
		int iVal = (int)sText.IndexOf(findString, startIndex, count, StringComparison.CurrentCulture); // 0 is start index and can be modified.
		return iVal;
	}
	// InStr - Overload END
	
	// if iText = "strafe" & oldChar = 'r', newChar = 'k', then "stkafe"
	public static string rReplace(string sText, char oldChar, char newChar){
		if (sText == null) { return "";}
		string strVal = sText.Replace(oldChar, newChar); // 0 is start index and can be modified.
		return strVal;
	}

	// if iText = "strafe" & oldStr = "tr", newStr = "", then "safe"
	public static string rReplace(string sText, string oldStr, string newStr){
		if (sText == null) { return "";}
		if (oldStr == null) { return "";}
		if (newStr == null) { return "";}
		if(sText.Length < oldStr.Length){return "";}
		string strVal = sText.Replace(oldStr, newStr); // 0 is start index and can be modified.
		return strVal;
	}
	
	
	// Mostly for error messages.
	private void Message(string message){
		MessageBox.Show(message);
	}
	
	// IF this is modified, it must also be modified in Module XMLFileFunctions
	// This is used only for find-replace (no colors)
	string[] searchArray = {
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		""
	};
	string[] replaceArray = {
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		""

	};
	// This is used only for find-COLOR-replace
	public static string[] pipeFindStringsBetweenDividersToColorArray = {
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		""
	};
	public static string[] pipeReplaceStringsBetweenDividersToColorArray = {
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		""

	};


	// used for only black text find-replace. this does not use colors
	public string getItemInReplaceArray(int itemNum)
	{
		return replaceArray[itemNum];
	}

	public void setItemInReplaceArray(int itemNum, string s)
	{
		replaceArray[itemNum] = s;
	}

	// used for only black text find-replace. this does not use colors
	public string getItemInFindArray(int itemNum)
	{
		return searchArray[itemNum];
	}

	public void setItemInFindArray(int itemNum, string s)
	{
		searchArray[itemNum] = s;
	}

	public string getPipeSearchArray(int aIndex)
	{
		return pipeFindStringsBetweenDividersToColorArray[aIndex];
	}


	public void reportError(string text, Exception ex)
	{
		Properties.pReportError.Text = "Email this error to: skywola@hotmail.com . . ." + Environment.NewLine + text;
		string caption = "Error Detected";
		string m = "Error:" + ex.StackTrace + ". . . ." + Environment.NewLine
			+ " Exception:  " + ex.ToString() + Environment.NewLine + Properties.pReportError.Text;
		MessageBox.Show(m, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
		
		FileIO FIO = new FileIO();
		// Write error to file
		string ErrorFilePath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Error";
		FIO.createDirectoryIfItDoesNotExist(ErrorFilePath);
		StreamWriter sw = new StreamWriter(ErrorFilePath, true, System.Text.Encoding.Unicode);
		sw.Write("Error:" + ex.StackTrace + ". . . ." + Environment.NewLine + ex.Message + Environment.NewLine + Environment.NewLine, ex);
		sw.Close();

	}


	
	public static List<string> getListOfFilesInDirectory(string directory, string fileExtension){
		
		List<string> fileList = new List<string>();

		string extUC = fileExtension.ToUpper();
		string extLC = fileExtension.ToLower();
		string[] fileEntries = Directory.GetFiles(@directory, "*" + extLC);
		foreach(string fileName in fileEntries){
			if(fileName.Contains(extLC) | fileName.Contains(extUC)){
				fileList.Add(Path.GetFileNameWithoutExtension(fileName));
			}
		}
		return fileList;
	}
	
	
	public void createDirAndFileIfNotExists(string filePath, string programDataDirectory)
	{
		if (!System.IO.Directory.Exists(programDataDirectory)) {
			Directory.CreateDirectory(programDataDirectory);
		}

		if (!File.Exists(filePath)) {
			FileIO io = new FileIO();
			io.writeFile(filePath, "");
		}
	}
	
	




	
	


}

