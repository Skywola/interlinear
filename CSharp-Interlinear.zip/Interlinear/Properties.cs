﻿using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

public static class Properties
	{
	public static string AppName = "Interlinear";
	// ReportError
	public static RichTextBox pReportError;
	public static bool go = true;
	public static string topFile = string.Empty;
	public static string bottomFile = string.Empty;
	public static string f1Path = string.Empty;
	public static string f2Path = string.Empty;
	public static string output = string.Empty;
	
	// This is a complete Section
	public static string sectionTop = string.Empty;
	public static string sectionBottom = string.Empty;
	public static string time = string.Empty;
	public static string subtitleTop = string.Empty;
	public static string subtitleBottom = string.Empty;
	
	public static bool exit = false;
	public static int count = 0;
	

	public static string buildTxt1 = string.Empty;
	public static string buildTxt2 = string.Empty;	
	

	
		
}

